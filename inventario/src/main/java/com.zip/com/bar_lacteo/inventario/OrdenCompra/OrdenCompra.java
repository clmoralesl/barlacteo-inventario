package com.bar_lacteo.inventario.OrdenCompra;

public class OrdenCompra {
    
}
