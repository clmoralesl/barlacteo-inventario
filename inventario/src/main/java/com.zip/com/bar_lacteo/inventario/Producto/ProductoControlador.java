package com.bar_lacteo.inventario.Producto;

public class ProductoControlador {
    
}
