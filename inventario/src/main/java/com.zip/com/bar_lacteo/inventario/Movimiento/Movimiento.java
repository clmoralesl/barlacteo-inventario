package com.bar_lacteo.inventario.Movimiento;

import jakarta.persistence.Entity;

@Entity
public class Movimiento {
    
}
